from django.db import models
import itertools

# Create your models here.
class user_login(models.Model):
    uname = models.CharField(max_length=100)
    password = models.CharField(max_length=25)
    u_type = models.CharField(max_length=10)

class user_details(models.Model):
    user_id = models.IntegerField()
    name = models.CharField(max_length=100)
    birthday = models.CharField(max_length=200)
    gender = models.CharField(max_length=500)
    email = models.CharField(max_length=500)
    password = models.CharField(max_length=500)
    phone = models.IntegerField()
    userphoto = models.ImageField(null=True)

    def __str__(self):
        return self.name

class station(models.Model):
    station_name =models.CharField(max_length=100)

    def __str__(self):
        return self.station_name

class police_details(models.Model):
    police_name = models.CharField(max_length=100)
    police_birthday = models.CharField(max_length=200)
    police_gender = models.CharField(max_length=500)
    police_email = models.CharField(max_length=500)
    police_password = models.CharField(max_length=500)
    police_phone = models.IntegerField()
    police_department = models.CharField(max_length=100)
    rank = models.CharField(max_length=100)
    Badge_number = models.IntegerField()
    Batch = models.IntegerField()
    police_photo = models.ImageField()
    stationn = models.ForeignKey(station,on_delete=models.CASCADE)

class complaint(models.Model):
    complaint_title = models.CharField(max_length=100)
    complaint_details = models.CharField(max_length=100)
    suspect = models.CharField(max_length=100)
    status = models.CharField(max_length=100, null=True)
    supporting_doc = models.FileField(upload_to ='uploads/')
    address = models.CharField(max_length=100)
    user = models.ForeignKey(user_details, on_delete=models.CASCADE)
    stationn = models.CharField(max_length=100)
    date = models.DateTimeField(auto_now_add=True)

class news(models.Model):
    newstitle = models.CharField(max_length=100)
    newscontent = models.CharField(max_length=200)
    newsimg = models.ImageField()
