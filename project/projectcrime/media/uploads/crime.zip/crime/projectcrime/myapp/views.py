from django.shortcuts import render
from .models import *
from django.db.models import Max, Min
from django.core.files.storage import FileSystemStorage
# Create your views here.
def signup(request):
    return render(request,'./myapp/signup.html')
def signup(request):
    if request.method=='POST':
        name=request.POST.get('name')
        birthday=request.POST.get('birthday')
        gender=request.POST.get('gender')
        email=request.POST.get('email')
        password=request.POST.get('password')
        phone=request.POST.get('phone')
        uname=email
        ul=user_login(uname=uname,password=password,u_type='user')
        ul.save()
        user_id=user_login.objects.all().aggregate(Max('id'))['id__max']
        ud=user_details(user_id=user_id,name=name,birthday=birthday,gender=gender,email=uname, password=password,phone=phone)
        ud.save()
        context={'msg':'User Registered'}
        return render(request,'./myapp/login.html',context)
    else:
        context={'msg':'Not Registered'}
        return render(request, './myapp/signup.html',context)
def login(request):
    return render(request,'./myapp/login.html')




def login(request):
    if request.method == 'POST':
        uname = request.POST.get('uname')
        password = request.POST.get('password')
                      #table uname=
        ul = user_login.objects.filter(uname=uname, password=password, u_type='user')
        ua = user_login.objects.filter(uname=uname, password=password, u_type='admin')
        up = police_details.objects.filter(police_email=uname, police_password=password)
        print(len(ul))
        if len(ul) == 1:
            request.session['user_id'] = ul[0].id
            request.session['user_name'] = ul[0].uname
            context = {'uname': request.session['user_name'],'ul':ul}
            #send_mail('Login','welcome'+uname,uname)
            return render(request, './myapp/userindex.html', context)

        elif len(ua) == 1:
            request.session['user_id'] = ua[0].id
            request.session['user_name'] = ua[0].uname
            context = {'uname': request.session['user_name'],'ua':ua}
            #send_mail('Login','welcome'+uname,uname)
            return render(request, 'myapp/adminhome.html', context)

        elif len(up) == 1:
            request.session['user_id'] = up[0].id
            request.session['user_name'] = up[0].police_email
            context = {'uname': request.session['user_name'], 'up': up}
            # send_mail('Login','welcome'+uname,uname)
            return render(request, 'myapp/policeindex.html', context)

        else:
            context = {'msg': 'Invalid Credentials'}
            return render(request, 'myapp/login.html', context)
    else:
        context = {'msg': 'No no no'}
        return render(request, 'myapp/login.html',context)
def police_details_view(request):
    viewpolicedetails = police_details.objects.all()
    vpd = {'details': viewpolicedetails}
    return render(request, './myapp/policedetails.html', vpd)
def policeindex(request):
    viewpolicedetails = police_details.objects.all()
    newsdetailscollect = news.objects.all()
    vpd = {'details': viewpolicedetails,'newsdisplay':newsdetailscollect}
    return render(request, './myapp/policeindex.html', vpd)

def userindex(request):
    viewpolicedetails = police_details.objects.all()
    newsdetailscollect = news.objects.all()
    vpd = {'details': viewpolicedetails,'newsdisplay':newsdetailscollect}
    return render(request, './myapp/userindex.html', vpd)

def test(request):
    viewpolicedetails = police_details.objects.all()
    vpd = {'details': viewpolicedetails}
    return render(request, './myapp/test.html', vpd)

def policehome(request):
    return render(request,'./myapp/policehome.html')
def userhome(request):
    return render(request,'./myapp/userhome.html')
def adminhome(request):
    return render(request,'./myapp/adminhome.html')
def about(request):
    return render(request,'./myapp/about.html')
def police_view_criminals(request):
    return render(request,'./myapp/police_view_criminals.html')
def police_view_complaints(request):
    return render(request,'./myapp/police_view_complaints.html')
def contact(request):
    return render(request,'./myapp/contact.html')
def filecomplaint(request):
    # ...............station list select in form...........
    stationselect = station.objects.all()
    ss = {'details': stationselect}
    # .................station list ends...................
    if request.method =='POST':
        u_file = request.FILES['supportingdocument']
        fs = FileSystemStorage()
        path = fs.save(u_file.name, u_file)
        complainttitle= request.POST.get('complainttitle')
        complaintdetails= request.POST.get('complaintdetails')
        suspect= request.POST.get('suspectdetails')
        address= request.POST.get('address')
        uname=request.session['user_name']
        userobj= user_details.objects.get(email=uname)
        stationn= request.POST.get('stationn')
        uc= complaint(complaint_title=complainttitle,complaint_details=complaintdetails, suspect=suspect, address=address ,user=userobj, stationn=stationn,supporting_doc=path)
        uc.save()
        ss = {'detail': uc}
        return render(request, './myapp/filecomplaint.html', ss)

    return render(request, './myapp/filecomplaint.html',ss)
def profile(request):
    uname = request.session['user_name']
    profiledisplay = user_details.objects.filter(email=uname)
    ss = {'details': profiledisplay}
    return render(request,'./myapp/profile.html',ss)

def policeprofile(request):
    uname = request.session['user_name']
    policeprofiledisplay = police_details.objects.filter(police_email=uname)
    ss = {'details': policeprofiledisplay}
    return render(request,'./myapp/policeprofile.html',ss)



def updateprofile(request):
    if request.method == 'POST':
        uname = request.session['user_name']
        up = user_details.objects.get(email=uname)
        u_file = request.FILES['userphoto']
        fs = FileSystemStorage()
        userphoto = fs.save(u_file.name, u_file)
        name = request.POST.get('name')
        birthday = request.POST.get('birthday')
        gender = request.POST.get('gender')
        email = request.POST.get('email')
        password = request.POST.get('password')
        phone = request.POST.get('phone')
        

        up.name = name
        up.birthday = birthday
        up.gender = gender
        up.email = email
        up.password = password
        up.phone = phone
        up.userphoto = userphoto
        up.save()


        context = {'msg': 'User Details Updated','up':up,'updatemsg':'product updated'}
        return render(request, 'myapp/updateprofile.html',context)

    else:
        user_id = request.session['user_id']
        up = user_details.objects.get(user_id=int(user_id))
        context={'up':up}
        return render(request, 'myapp/updateprofile.html',context)


def policeupdateprofile(request):
    if request.method == 'POST':
        uname = request.session['user_name']
        user_id = request.session['user_id']
        # up = user_details.objects.get(email=uname)
        upp = police_details.objects.get(id=user_id)
        # u_file = request.FILES['userphoto']
        u_file = request.FILES['police_photo']
        
        # userphoto = fs.save(u_file.name, u_file)
        # fs = FileSystemStorage()
        # name = request.POST.get('name')
        police_name = request.POST.get('police_name')
        police_birthday = request.POST.get('police_birthday')
        police_email = request.POST.get('police_email')
        police_password = request.POST.get('police_password')
        police_phone = request.POST.get('police_phone')
        phone = request.POST.get('phone')


        # up.name = name
        upp.police_name = police_name
        # up.birthday = birthday
        upp.police_birthday = police_birthday
        upp.police_email = police_email
        upp.police_password = police_password
        upp.police_phone = police_phone
        upp.police_photo = u_file
        upp.save()
        # up.gender = gender
        # up.email = email
        # up.password = password
        # up.phone = phone
        # up.userphoto = userphoto
        # up.police_photo = userphoto
        # up.save()


        context = {'msg': 'User Details Updated','upp':upp,'updatemsg':'profile updated'}
        return render(request, 'myapp/policeupdateprofile.html',context)

    else:
        user_id = request.session['user_id']
        print(user_id)
        up = police_details.objects.get(id=int(user_id))
        context={'upp':up}
        return render(request, 'myapp/policeupdateprofile.html',context)


def logout(request):
    try:
        del request.session['user_name']

        del request.session['user_id']
    except:
        return login(request)
    else:
        return login(request)