"""projectcrime URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path  
from.import views

urlpatterns = [
    path('signup.html',views.signup,name='signup'),
    path('login', views.login, name='login'),
    path('', views.login, name='login'),
    path('policehome',views.policehome,name='policehome'),
    path('policehome.html',views.policehome,name='policehome'),
    path('policeindex.html',views.policeindex,name='policeindex'),
    path('userindex.html',views.userindex,name='userindex'),
    path('policehome.html',views.police_details_view,name='police_details_view'),
    path('userhome.html',views.policehome,name='userhome'),
    path('policedetails.html',views.police_details_view,name='policedetails'),
    path('userhome',views.policehome,name='userhome'),
    path('adminhome.html',views.policehome,name='adminhome'),
    path('adminhome',views.policehome,name='adminhome'),
    path('about.html',views.about,name='about'),
    path('contact.html',views.contact,name='contact'),
    path('filecomplaint.html',views.filecomplaint,name='filecomplaint'),
    path('police_view_complaints.html',views.police_view_complaints,name='listing-page'),
    path('police_view_criminals.html',views.police_view_criminals,name='detail-page'),
    path('test.html', views.test, name='test'),
    path('profile.html', views.profile, name='profile'),
    path('policeprofile.html', views.policeprofile, name='policeprofile'),
    path('updateprofile.html', views.updateprofile, name='updateprofile'),
    path('policeupdateprofile.html', views.policeupdateprofile, name='policeupdateprofile'),
    path('logout', views.logout, name='logout'),

]