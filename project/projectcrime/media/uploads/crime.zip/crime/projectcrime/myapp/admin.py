from django.contrib import admin

from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(user_login)
admin.site.register(user_details)
admin.site.register(police_details)
admin.site.register(station)
admin.site.register(complaint)
admin.site.register(news)